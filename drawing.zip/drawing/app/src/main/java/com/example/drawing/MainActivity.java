package com.example.drawing;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Toast;

import com.example.drawing.projectdraw.projectView;


public class MainActivity extends AppCompatActivity {
    private projectView projectview;
    AlertDialog dialog;
    private AlertDialog.Builder currentalertdialog;
    private ImageView imageView;
    private SeekBar alphas;
    private SeekBar reds;
    private SeekBar greens;
    private SeekBar blues;
    private View colorview;
    private AlertDialog colordialog;
    String radious;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        projectview= findViewById(R.id.view);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.clearid:
                projectview.clear();
                break;
            case R.id.saveid:

                break;
            case R.id.colorid:
                showcolordialog();
                break;
            case R.id.eraseid:
                break;
            case R.id.linewidth:
                showlinedialogalert();
                break;
            case R.id.circleid:

                break;

        }
        return super.onOptionsItemSelected(item);

    }

    /* void showcirclealertdialog ()
    {
        currentalertdialog=new AlertDialog.Builder(this);
        View view=getLayoutInflater().inflate(R.layout.circle,null);
        Button b=(Button)findViewById(R.id.buttonok);
        final EditText  e=findViewById(R.id.radiousfield);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 radious=e.getText().toString();
                 int r=Integer.parseInt(radious);
                 Canvas canvas=new Canvas();
                 Paint p=new Paint();
                 p.setColor(150);
                 canvas.drawCircle(100,100,r,p);
            }
        });
        currentalertdialog.setView(view);
        currentalertdialog.create();
        currentalertdialog.show();
    }*/

    void showlinedialogalert(){
        currentalertdialog=new AlertDialog.Builder(this);
        View view=getLayoutInflater().inflate(R.layout.width_dialog,null);
        final SeekBar widthseekbar=view.findViewById(R.id.widthseekBar);
        Button setlinewidthbutton=view.findViewById(R.id.widthdialogbutton);
        imageView=view.findViewById(R.id.imageViewid);
        setlinewidthbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                projectview.setlinewidth(widthseekbar.getProgress());
                dialog.dismiss();
                currentalertdialog=null;
            }
        });
        widthseekbar.setOnSeekBarChangeListener(widthseekbarchange);
        currentalertdialog.setView(view);
        dialog=currentalertdialog.create();
        dialog.show();
    }
    private  SeekBar.OnSeekBarChangeListener widthseekbarchange=new SeekBar.OnSeekBarChangeListener() {
        Bitmap bitmap=Bitmap.createBitmap(400,100, Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(bitmap);
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {


            Paint p=new Paint();
            p.setColor(projectview.getdrawingcolor());
            p.setStrokeWidth(progress);
            p.setStrokeCap(Paint.Cap.ROUND);
             bitmap.eraseColor(Color.WHITE);
             canvas.drawLine(30,50,370,50,p);
             imageView.setImageBitmap(bitmap);
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    } ;

     public void showcolordialog(){
        currentalertdialog=new AlertDialog.Builder(this);
        View view=getLayoutInflater().inflate(R.layout.color_dialog,null);
         alphas=view.findViewById(R.id.alphaseekbar);
         reds=view.findViewById(R.id.redseekbar);
         greens=view.findViewById(R.id.greenseekbar);
         blues=view.findViewById(R.id.blueseekbar4);
         colorview =view.findViewById(R.id.colorview);
        Button colorbutton=view.findViewById(R.id.colorbutton);

        alphas.setOnSeekBarChangeListener(colorseekbarchanged);
        reds.setOnSeekBarChangeListener(colorseekbarchanged);
        greens.setOnSeekBarChangeListener(colorseekbarchanged);
        blues.setOnSeekBarChangeListener(colorseekbarchanged);

        int colori=projectview.getdrawingcolor();
        alphas.setProgress(Color.alpha(colori));
        reds.setProgress(Color.red(colori));
        greens.setProgress(Color.green(colori));
        blues.setProgress(Color.blue(colori));
        colorbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                projectview.setdrawingcolor(Color.argb(alphas.getProgress()
                        ,reds.getProgress(),
                        greens.getProgress(),
                        blues.getProgress())
                );
                colordialog.dismiss();
            }
        });
        currentalertdialog.setView(view);
        currentalertdialog.setTitle("choose color");
        colordialog=currentalertdialog.create();
        colordialog.show();




    }
    private SeekBar.OnSeekBarChangeListener colorseekbarchanged=new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            projectview.setBackgroundColor(Color.argb(
                    alphas.getProgress(),reds.getProgress(),greens.getProgress(),blues.getProgress()
            ));
            colorview.setBackgroundColor(Color.argb(alphas.getProgress()
                    ,reds.getProgress(),
                    greens.getProgress(),
                    blues.getProgress()));

        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    };
}
