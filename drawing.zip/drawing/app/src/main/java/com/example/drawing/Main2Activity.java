package com.example.drawing;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.BlurMaskFilter;
import android.graphics.Paint;
import android.os.Bundle;
import android.widget.EditText;

import com.example.drawing.projectdraw.views.custom_views;

public class Main2Activity extends AppCompatActivity {
    custom_views customviews;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        customviews=new custom_views(this); //creating the instance
        setContentView(customviews);
    }

}
