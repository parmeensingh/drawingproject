package com.example.drawing.projectdraw;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;

public class projectView extends View {
    public static final float touchy=10;
    private Bitmap bitmap;
    private Canvas canvas;
    private Paint paints;
    private Paint paintline;
    private HashMap<Integer, Path>hashMappath;
    private HashMap<Integer, Point> hashMappoint;
    public projectView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();

    }

    void init()
    {
        paints=new Paint();
        paintline=new Paint();
        paintline.setAntiAlias(true);
        paintline.setColor(Color.BLACK);
        paintline.setStyle(Paint.Style.STROKE);
        paintline.setStrokeWidth(7);
        paintline.setStrokeCap(Paint.Cap.ROUND);
        hashMappath=new HashMap<>();
        hashMappoint=new HashMap<>();
    }
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {

        bitmap=Bitmap.createBitmap(getWidth(),getHeight(), Bitmap.Config.ARGB_8888);
        canvas=new Canvas(bitmap);
        bitmap.eraseColor(Color.WHITE);


    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawBitmap(bitmap,0,0,paints);
        for(Integer key: hashMappath.keySet())
        {
            canvas.drawPath(hashMappath.get(key),paintline);

        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int act=event.getAction();
        int actionindex=event.getActionIndex();
        if (act==MotionEvent.ACTION_DOWN || act==MotionEvent.ACTION_POINTER_UP)
        {
            touchStarted(event.getX(actionindex),event.getY(actionindex),event.getPointerId(actionindex));

        }
        else if (act==MotionEvent.ACTION_UP||act==MotionEvent.ACTION_POINTER_UP)
        {
            touchEnded(event.getPointerId(actionindex));
        }
        else
        {
            touchMoved(event);
        }
        invalidate();
        return true;
    }

    private void touchMoved(MotionEvent event) {
        for (int i=0;i<event.getPointerCount();++i)
        {
            int pointerid=event.getPointerId(i);
            int pointerindex=event.findPointerIndex(i);
            if (hashMappath.containsKey(pointerid))
            {
                float newx=event.getX(pointerindex);
                float newy=event.getY(pointerindex);

                Path path=hashMappath.get(pointerid);
                Point point=hashMappoint.get(pointerid);

                float deltax=Math.abs(newx-point.x);
                float deltay=Math.abs(newy-point.y);

                if (deltax>=touchy||deltay>=touchy)
                {
                    path.quadTo(point.x,point.y,(newx+point.x)/2,(newy+point.y)/2);
                    point.x=(int)newx;
                    point.y=(int)newy;
                }
            }
        }
    }

    private void touchEnded(int pointerId) {
        Path path=hashMappath.get(pointerId);
        canvas.drawPath(path,paintline);
        path.reset();
    }
    public void setdrawingcolor(int color){
        paintline.setColor(color);
    }
    public int getdrawingcolor()
    {
        return paintline.getColor();
    }
    public void setlinewidth(int width){
        paintline.setStrokeWidth(width);
    }
    int getlinewidth(){
        return (int)paintline.getStrokeWidth();
    }


    public void clear()
    {
        hashMappath.clear();
        hashMappoint.clear();
        bitmap.eraseColor(Color.WHITE);
        invalidate();
    }

    private void touchStarted(float x, float y, int pointid) {
        Path path;
        Point point;
        if (hashMappath.containsKey(pointid))
        {
            path=hashMappath.get(pointid);
            point=hashMappoint.get(pointid);

        }
        else{
            path=new Path();
            hashMappath.put(pointid,path);
            point=new Point();
            hashMappoint.put(pointid,point);
        }

        path.moveTo(x,y);
        point.x=(int)x;
        point.y=(int)y;

    }

}
